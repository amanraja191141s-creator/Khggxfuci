# SA Calculator v98.31 — Release verification

Current source identity: `1.98.31-v98.31`  
Android versionCode: `1098031`

## Verified
- `npm test`: 242 passed, 0 failed, 0 skipped.
- `npm run build:web`: 10 required runtime assets verified.
- JavaScript syntax checks passed.
- HTML duplicate-ID scan found zero duplicates.
- All 105 selectable currency codes have a representative flag mapping.
- Android workflow copies are byte-identical and YAML parsing succeeds.
- Package, manifest, app runtime, service worker and workflow version identities agree.

## Not certified
- APK has not been built or installed on a physical Android device in this environment.
- Target-device rendering, keyboard/IME behavior, live exchange providers, FPS, memory, battery, ANR and long-session stability require device/CI execution.
- No universal zero-bug or zero-lag guarantee is made.

Historical continuity: `1.98.2-v98.2` describes an earlier release verification and is not the current release identity.
