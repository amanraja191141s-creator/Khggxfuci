# SA Calculator v98.31 — File-by-file audit

Release: `1.98.31-v98.31`  
Scope: premium UI rebuild based on v98.30 source.

| File | Responsibility | v98.31 treatment |
|---|---|---|
| `index.html` | App shell, 18 screen destinations, menus, dialogs and tool forms | Navigation and scientific UI rebuilt; original screen IDs and input IDs preserved. |
| `assets/js/app.js` | Calculator, tool calculations, currency providers, navigation and persistence | Calculation and rate engines retained; menu search, favorites quick access and all-currency flag display added. |
| `assets/css/app.css` | Themes, calculator layouts, dialogs and responsive rules | New premium presentation layer appended; compatibility selectors retained to avoid breaking legacy screen controls. |
| `assets/js/localization.js` | Interface localization | Preserved. |
| `assets/js/currency-localized-names.js` | Localized currency names | Preserved; used with ISO code and region labels. |
| `assets/js/theme-bootstrap.js` | First-paint theme restoration | Preserved and precached. |
| `service-worker.js` | Offline app shell and same-origin asset caching | Cache namespace bumped to `sa-calculator-v98-31-premium-rebuild`. API responses remain uncached. |
| `manifest.webmanifest` | PWA metadata | Version aligned to `1.98.31-v98.31`. |
| `package.json` | Project scripts and dependencies | Version aligned; tests and Android build scripts retained. |
| `scripts/prepare-android-web.mjs` | Android web staging | Generates and verifies the `www/` bundle. |
| `scripts/patch-android-native.mjs` | Android branding and native inset patch | Preserved. |
| `.github/workflows/main.yml` | Android debug APK CI | Exact v98.31 source selection and versionCode `1098031`. |
| `tests/` | Regression coverage | 242 tests pass in the staged source package. |

## UI changes

- Visible home hamburger and searchable tool library.
- 16 tools grouped into clear categories; Quick access follows saved favorites.
- All 105 selectable currency codes have representative flag mappings.
- Currency picker shows flag, localized currency name, ISO code and region name.
- Scientific functions grouped into five families.
- Shared on-demand keyboard restyled as a safe-area-aware bottom sheet.
- Tool fields, cards, result surfaces, buttons and navigation share a premium visual language.

## Compatibility decision

The visible legacy UI is superseded by the v98.31 design layer. Older CSS compatibility rules are retained underneath the final design overrides because existing tool forms and stateful controls still depend on their layout selectors. Calculation engines, rate logic and persisted data were not destructively removed.

Historical continuity: the earlier `1.97.1-v97.1` audit remains a record of that older release only.

## QA boundary

Source tests and web bundle generation pass. Physical APK installation, target-device screenshot comparison, live network behavior and performance certification remain outstanding.

## Currency API deployment statement

No private Cloudflare Worker, private API adapter, provider credential or custom server-side currency proxy is shipped. The app calls the documented public providers directly; offline cache and built-in estimates remain explicitly distinguished from live rates.
