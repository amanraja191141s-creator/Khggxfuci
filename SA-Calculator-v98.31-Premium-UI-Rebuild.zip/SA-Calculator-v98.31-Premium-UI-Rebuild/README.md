# SA Calculator v98.31 — Premium UI Rebuild

A clean source release of SA Calculator with a redesigned navigation library, currency selector, on-demand numeric keypad, scientific calculator panel, and shared premium tool UI system.

## Release identity
- Package version: `1.98.31-v98.31`
- Android versionCode: `1098031`
- Web runtime cache: `sa-calculator-v98-31-premium-rebuild`

## Included
- `index.html`, `assets/`, `scripts/`, `tests/`, and generated `www/` bundle.
- Capacitor project configuration and Android native branding/inset patch scripts.
- GitHub Actions Android debug APK workflow in `.github/workflows/main.yml`.
- Standalone synchronized workflow copies at the project root.
- Rebuild notes, release notes, and change register.

## Build and test
```bash
npm install
npm test
npm run build:web
```

For a local Android debug APK (Android SDK + JDK required):
```bash
npm run android:apk
```

GitHub Actions can also build and upload the debug APK using the included workflow.

## Design and behavior
- Home header has a visible hamburger entry point; tool pages use one tool-specific toolbar.
- Drawer has searchable categories, 16 tool destinations, and a Quick access section based on saved favorites.
- Every one of the 105 selectable currency codes has a representative country/region flag, full currency name, ISO code, and region label in the currency picker.
- Scientific functions are grouped by family; DEG/RAD and memory controls remain available.
- Numeric tools use the custom on-demand keyboard; the basic calculator retains its permanent keypad.
- Calculation engines, currency-rate providers/cache/freshness logic, screen IDs, saved settings, favorites and history are preserved.

## Verification limits
The included automated suite has 242 passing tests and the web bundle is generated. A physical Android install, live provider/network test, screenshot comparison on device, FPS/memory/battery measurements, and release signing remain device/CI verification tasks. Do not treat source tests as proof of zero bugs or zero lag.

## Currency flag note
Flags are representative visual identifiers for each selectable currency. Regional currencies may use a regional/territory flag (for example EUR uses EU). The ISO 4217 currency code and localized currency name are authoritative; a flag alone does not define legal tender coverage.
