# QA Results — v98.31

## Passed in this environment
- JavaScript syntax checks for app, server, service worker and build scripts.
- 242 automated Node regression tests: 242 passed, 0 failed, 0 skipped.
- Android web bundle generation: 10 required runtime assets verified.
- Source and generated `www` HTML/JS/CSS are synchronized by the web build script.
- Three root workflow copies match `.github/workflows/main.yml` byte-for-byte.
- Workflow YAML parsed successfully.
- HTML duplicate-ID scan: 0 duplicate IDs.
- Selectable currency catalog: 105 codes; 105 representative flag mappings; 0 missing mappings.

## Not performed / still required
- APK build in an Android SDK runner.
- APK installation and physical Android testing.
- Real-time currency provider requests from the target device/network.
- Device screenshots at 320dp/360dp and on the user's exact phone.
- Native keyboard/IME behavior for every field on the target Android version.
- FPS, frame jank, memory, battery, ANR and long-duration stability measurements.
- Signed release APK/AAB and Play Console validation.

A passing source test suite is not a guarantee of bug-free or lag-free behavior on every device.
